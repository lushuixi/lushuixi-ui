export default {
    name: "YTableHeader",
    render(h) {
        console.log('YTableHeader-render函数');
        // return (
        //     <span>55</span>
        // )
        return h('span')
    }
}