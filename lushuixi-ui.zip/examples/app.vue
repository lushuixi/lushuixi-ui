<template>
    <div id="app">
        <!-- helleo -->
        <!-- <router-link to="/index">go page1</router-link> -->
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name: 'App',
}
</script>
