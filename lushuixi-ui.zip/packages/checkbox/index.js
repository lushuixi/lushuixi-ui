import LCheckbox from './src/checkbox';

LCheckbox.install = function (Vue) {
    Vue.component(LCheckbox.name, LCheckbox);
};

export default LCheckbox;