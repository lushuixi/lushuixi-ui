<template>
    <div class="l-button">
        buttonbuttonbuttonbutton
    </div>
</template>

<script>
export default {

    name: 'LButton',

}
</script>
