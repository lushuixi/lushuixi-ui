import LRadioGroup from '../radio/src/radio-group';

LRadioGroup.install = function(Vue) {
    Vue.component(LRadioGroup.name, LRadioGroup);
}

export default LRadioGroup;