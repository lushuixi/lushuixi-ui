import LCheckboxGroup from '../checkbox/src/checkbox-group';

LCheckboxGroup.install = function (Vue) {
    Vue.component(LCheckboxGroup.name, LCheckboxGroup);
};

export default LCheckboxGroup;